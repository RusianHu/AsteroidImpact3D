<script setup lang="ts">
import AsteroidImpactScene from './components/AsteroidImpactScene.vue'
</script>

<template>
  <AsteroidImpactScene />
</template>

<style>
/* 全局样式 */
html, body {
  margin: 0;
  padding: 0;
  overflow: hidden;
  width: 100%;
  height: 100%;
  font-family: 'Arial', sans-serif;
}

#app {
  width: 100%;
  height: 100%;
}
</style>
